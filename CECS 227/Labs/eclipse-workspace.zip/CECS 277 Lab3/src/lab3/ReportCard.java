package lab3;
/*
 * Banh, Alex
 * CECS 277
 * Professor Phuong Nguyen
 * 25 September, 2019
 */
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * Sets classes for a and calculates the GPA of the student
 * @author alexb
 *
 */
public class ReportCard {
	Map <String, Character> studentClass;
	double gpa; 
	/**
	 * The default report card constructor
	 */
	public ReportCard() {
		studentClass = new HashMap <String, Character>();
		gpa = 0.0;
	}
	/**
	 * The normal report card constructor
	 * @param nStudentClass The classes the student is taking
	 * @param nGpa The student's GPA
	 */
	public ReportCard(Map<String, Character> nStudentClass, double nGpa) {
		studentClass = new HashMap<String, Character>(nStudentClass);
		gpa = nGpa;
	}
	/**
	 * Add a class and grade to a student
	 * @param nClassName Name of class
	 * @param nGrade Grade they got
	 */
	public void addClass(String nClassName, Character nGrade) {
		studentClass.put(nClassName, nGrade);
		calculateGPA();
	}
	/**
	 * Select a class to remove from the student's class list
	 * @param nClassName The name of the class to be removed
	 */
	public void removeClass(String nClassName) {
		studentClass.remove(nClassName);
		calculateGPA();
	}
	/**
	 * Returns all the student's classes
	 * @return The classes the student is taking
	 */
	public Map<String, Character> getStudentClass() {
		return studentClass;
	}
	/**
	 * Return's the student's GPA
	 * @return Returns the student's GPA
	 */
	public double getGPA() {
		return gpa;
	}
	/**
	 * Calculates the GPA of the student's based on the classes they took
	 */
	private void calculateGPA() {
		gpa = 0;
		int totalClasses = 0;
		Set<Entry<String, Character>> st = studentClass.entrySet();    
		for (Map.Entry< String, Character> me:st)
		{
			if (me.getValue() == 'A')
				gpa += 4;
			else if (me.getValue() == 'B')
				gpa += 3;
			else if (me.getValue() == 'C')
				gpa += 2;
			else if (me.getValue() == 'D')
				gpa += 1;

			totalClasses++;
		}
		gpa /= totalClasses;
	}
	/**
	 * Prints out the student's classes, their grades, and their GPA
	 */
	public String toString() {
		String classes = "";
		Set<Entry<String, Character>> st = studentClass.entrySet();    
		for (Map.Entry< String, Character> me:st)
		{
			classes += me.getKey() + ": " + me.getValue() + "\n";
		}
		return "Classes: \n" + classes + "GPA: " + gpa;
	}
}
	