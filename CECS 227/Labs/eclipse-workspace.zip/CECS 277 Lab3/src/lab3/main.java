package lab3;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReportCard jamie = new ReportCard();
		jamie.addClass("Math", 'A');
		jamie.addClass("English", 'B');
		jamie.addClass("History", 'C');
		jamie.addClass("Science", 'B');
		jamie.addClass("Band", 'A');
		System.out.println("Student Grades: \n"+ jamie.toString());

		jamie.removeClass("Math");
		System.out.println("Student Grades: \n"+ jamie.toString());
		
		System.out.println("Classes: \n" + jamie.getStudentClass() + "\nGPA: " + jamie.getGPA());
	}

}
