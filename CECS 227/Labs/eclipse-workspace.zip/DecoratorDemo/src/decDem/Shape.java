package decDem;

public interface Shape {
	 void draw();
	}

