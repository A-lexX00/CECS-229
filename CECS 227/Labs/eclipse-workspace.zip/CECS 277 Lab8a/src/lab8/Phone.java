package lab8;

public class Phone implements Visitable{
	private double pPrice;
	private String pModName;
	private String pBrandName;
	protected int quant;
	
	Phone(){
		pPrice = 0.0;
		pModName = "";
		pBrandName = "";
		quant = 0;
	}
	
	Phone(double nPrice, String nModName, String nBrandName, int nQuant){
		pPrice = nPrice;
		pModName = nModName;
		pBrandName = nBrandName;
		quant = nQuant;
		
		if(pBrandName.equalsIgnoreCase("APPLE"))
		{
			if(pPrice > 400.0)
				appleDiscount();
		}
		else if(pBrandName.equalsIgnoreCase("SAMSUNG"))
		{
			if(pModName.equalsIgnoreCase("Galaxy S8"))
				galaxyDiscount();
		}
	}
	
	public double getPrice() {
		return pPrice;
	}
	public double getQuant() {
		return quant;
	}
	public void setPrice(double price) {
		pPrice = price;
	}
	
	public void appleDiscount() {
		System.out.println("Apple Discount applied");
		pPrice -= 30;
	}
	public void galaxyDiscount() {
		System.out.println("Samsung Discount applied");
		pPrice = pPrice * 0.8;
		
	}
	
	public void print() {
		System.out.println(pBrandName + " " + pModName + "\nQuantity: " + quant + "\nTotal Price: $" + pPrice * quant);
	}
	@Override
	public void accept(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}

}
