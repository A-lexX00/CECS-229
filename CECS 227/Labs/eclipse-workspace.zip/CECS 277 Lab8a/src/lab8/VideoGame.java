package lab8;

public class VideoGame implements Visitable{
	private double vgPrice;
	private String vgGameName;
	private String vgCompName;
	protected int quant;
	
	VideoGame(){
		vgPrice = 0.0;
		vgGameName = "";
		vgCompName = "";
		quant = 1;
	}
	
	VideoGame(double nPrice, String nGameName, String nCompName, int nQuant){
		vgPrice = nPrice;
		vgGameName = nGameName;
		vgCompName = nCompName;
		quant = nQuant;
		
		if(nCompName.equalsIgnoreCase("Sony"))
		{
			if(nGameName.equalsIgnoreCase("Playstation"))
				sonyDiscount();
		}
		else if(nCompName.equalsIgnoreCase("Microsoft"))
		{
			if(nGameName.equalsIgnoreCase("Xbox One"))
			{
				if(quant == 2)
					XboxDiscount();
			}
		}
	}
	public double getQuant() {
		return quant;
	}
	public double getPrice() {
		return vgPrice;
	}
	public void setPrice(double price) {
		vgPrice = price;
	}
	
	public void sonyDiscount() {
		System.out.println("Sony Discount applied");
		vgPrice = vgPrice * 0.8;
	}
	public void XboxDiscount() {
		System.out.println("Xbox Discount applied");
		vgPrice = vgPrice * 0.7;
	}
	
	public void print() {
		System.out.println(vgCompName + " " + vgGameName + "\nQuantity: " + quant + "\nTotal Price: $" + vgPrice * quant);
	}
	@Override
	public void accept(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}

}
