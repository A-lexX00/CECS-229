package lab8;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Electronics allItems = new Electronics();
		Scanner in = new Scanner(System.in);
		
		//allItems.addToCart(new Laptop(500.0, "Surface", "Microsoft", 2));
		//allItems.addToCart(new Phone(1000.0, "X Max", "Apple", 1));
		//allItems.addToCart(new Phone(700.0, "Galaxy S8", "Samsung", 1));
		//allItems.addToCart(new VideoGame(300.0, "Playstation", "Sony", 2));
		//allItems.addToCart(new VideoGame(300.0, "Xbox One", "Microsoft", 2));
		
		int choice = 0;
		do {
			System.out.println("Welcome to the Microsoft Store!");
			System.out.println("What would you like to buy?");
			System.out.println("Hit 1 for phone, 2 for laptop, 3 for video game console, 4 to quit");
			choice = in.nextInt();
			
				switch(choice) {
				case 1	: {
					System.out.println("How much is the phone?");
					double price = in.nextDouble();
					System.out.println("What's the name of it?");
					String name = in.next();
					System.out.println("Which company desgined it");
					String brand = in.next();
					System.out.println("How much is the phone?");
					int quant = in.nextInt();
					allItems.addToCart(new Phone(price, name, brand, quant));
					break;
				}
				case 2	: {
					System.out.println("How much is the laptop?");
					double price = in.nextDouble();
					System.out.println("What's the name of it?");
					String name = in.next();
					System.out.println("Which company desgined it");
					String brand = in.next();
					System.out.println("How much is the phone?");
					int quant = in.nextInt();
					allItems.addToCart(new Laptop(price, name, brand, quant));
					break;
				}
				case 3	: {
					System.out.println("How much is the console?");
					double price = in.nextDouble();
					System.out.println("What's the name of it?");
					String name = in.next();
					System.out.println("Which company desgined it");
					String brand = in.next();
					System.out.println("How much is the phone?");
					int quant = in.nextInt();
					allItems.addToCart(new VideoGame(price, name, brand, quant));
					break;
				}
				default	: {
					System.out.println("Thank you! See you again!");
					break;
				}
				
			}

		}while(choice < 4);
		
		for (Visitable vis : allItems.shoppingCart) {
				
				if (vis instanceof Phone)
		 			((Phone) vis).print();
		 		else if (vis instanceof Laptop)
		 			((Laptop) vis).print();
		 		else if (vis instanceof VideoGame)
		 			((VideoGame) vis).print();	
		 		else
		 			System.out.println("Not in cart");
		}
		
		allItems.accept(new PriceChecker());
		
		System.out.println("Cart total: $" + allItems.returnTotal());
	}

}
