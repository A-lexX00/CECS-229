package lab8;

public interface Visitor {
	public abstract void visit(Laptop laptop);
	public abstract void visit(Phone phone);
	public abstract void visit(VideoGame videoGame);
	public abstract void visit(Electronics electronics);
}
