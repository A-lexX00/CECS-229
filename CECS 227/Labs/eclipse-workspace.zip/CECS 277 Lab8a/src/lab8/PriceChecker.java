package lab8;

public class PriceChecker implements Visitor{

	@Override
	public void visit(Laptop laptop) {
		// TODO Auto-generated method stub
		System.out.println("Adding laptop to cart");
	}

	@Override
	public void visit(Phone phone) {
		// TODO Auto-generated method stub
		System.out.println("Adding phone to cart");	
	}

	@Override
	public void visit(VideoGame videoGame) {
		// TODO Auto-generated method stub
		System.out.println("Adding video game to cart");	
	}

	@Override
	public void visit(Electronics electronics) {
		// TODO Auto-generated method stub
		System.out.println("Filling cart");	
	}

}
