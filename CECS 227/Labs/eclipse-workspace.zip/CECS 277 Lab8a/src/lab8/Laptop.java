package lab8;

public class Laptop implements Visitable{
	private double lapPrice;
	private String lapCompName;
	private String lapBrandName;
	protected int quant;
	
	Laptop(){
		lapPrice = 0.0;
		lapCompName = "";
		lapBrandName = "";
		quant = 0;
	}
	
	Laptop(double nPrice, String nCompName, String nBrandName, int nQuant){
		lapPrice = nPrice;
		lapCompName = nCompName;
		lapBrandName = nBrandName;
		quant = nQuant;
		
		if (nCompName.equalsIgnoreCase("Surface"))
			surfacePriceReduction();
	}

	public double getQuant() {
		return quant;
	}
	public double getPrice() {
		return lapPrice;
	}
	public void setPrice(double price) {
		lapPrice = price;
	}
	public void surfacePriceReduction() {
		System.out.println("Surface Discout applied");
		lapPrice = lapPrice * 0.8;
	}
	
	public void print() {
		System.out.println(lapBrandName + " " + lapCompName + "\nQuantity: " + quant + "\nTotal Price: $" + lapPrice * quant);
	}
	@Override
	public void accept(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	}


}