package lab8;

import java.util.ArrayList;
import java.util.List;


public class Electronics implements Visitable{
	public List<Visitable> shoppingCart = new ArrayList<Visitable>();
	protected double cartTotal;
	protected int cartItems;
	
	@Override
	public void accept(Visitor visitor) {
		// TODO Auto-generated method stub
		visitor.visit(this);
	 	for (Visitable vis: shoppingCart) {
	 		vis.accept(visitor);
	 	}
	}
	
	public double returnTotal() {
		return cartTotal;
	}
	
	public void addToCart(Visitable item) {
 		if (item instanceof Phone) {
 			for(int i = 0; i < ((Phone) item).getQuant(); i++)
 			{
 				cartTotal += ((Phone) item).getPrice();
 				cartItems++;
 			}
 		}
 		else if (item instanceof Laptop)
 		{
 			for(int i = 0; i < ((Laptop) item).getQuant(); i++)
 			{
 				cartTotal += ((Laptop) item).getPrice();
 				cartItems++;
 			}
 		}
 		else if (item instanceof VideoGame)
 		{
 			for(int i = 0; i < ((VideoGame) item).getQuant(); i++)
			{
				cartTotal += ((VideoGame) item).getPrice();
				cartItems++;
			}
 		}
 		
 		shoppingCart.add(item);
 	}

}
