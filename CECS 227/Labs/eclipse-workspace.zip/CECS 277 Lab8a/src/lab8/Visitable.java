package lab8;

public interface Visitable {
	public abstract void accept(Visitor visitor);
}
