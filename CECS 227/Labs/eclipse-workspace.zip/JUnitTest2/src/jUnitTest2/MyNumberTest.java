package jUnitTest2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MyNumberTest {

	private MyNumber number1, number2; // Test fixtures
	 
	@Before
	 public void setUp() throws Exception {
		System.out.println("Run @Before"); // for illustration
	 	number1 = new MyNumber(11);
	 	number2 = new MyNumber(22);
	 }
	 
	 @After
	 public void tearDown() throws Exception {
		 System.out.println("Run @After"); // for illustration
	 }
	 
	 @Test
	 public void testGetterSetter() {
		 System.out.println("Run @Test testGetterSetter"); // for illustration
	 	int value = 33;
	 	number1.setNumber(value);
	 	assertEquals("error in getter/setter", 12, number1.getNumber());  // pass: value, fail: others
	 }
	 
	 @Test
	 public void testAdd() {
		System.out.println("Run @Test testAdd"); // for illustration
	 	assertEquals("error in add()", 23, number1.add(number2).getNumber()); // pass: 33, fail: others
	 	assertEquals("error in add()", 25, number1.add(number2).getNumber()); // pass: 55, fail others
	 }
	 
	 @Test
	 public void testDiv() {
		 System.out.println("Run @Test testDiv"); // for illustration
	 	assertEquals("error in div()", 1, number2.div(number1).getNumber()); // pass: 2, fail: others
	 	assertEquals("error in div()", 10, number2.div(number1).getNumber()); // pass 0, fail: others
	 }
	 
	 @Test(expected = IllegalArgumentException.class)
	 public void testDivByZero() {
		 System.out.println("Run @Test testDivByZero"); // for illustration
		 number2.setNumber(0);
		 number1.div(number1); // pass: number2, fail: number1
	 }
}
