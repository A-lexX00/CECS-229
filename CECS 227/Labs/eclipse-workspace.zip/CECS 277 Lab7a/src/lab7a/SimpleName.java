package lab7a;
public class SimpleName implements NameInterface {
	String name;
	
	public void setName(String n) {
		name = n;
	}
	
	public String getName() {
		return name;
	}
}
