package project1;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.io.Serializable;
import java.text.DecimalFormat;

/**
 * The class Faculty creates a faulty object that is extended from 
 * Employee and is cloneable to store Faculty data
 * @author alexb
 *
 */
public class Faculty implements Employee, Cloneable, Serializable{

	public enum Rank {
		AS, AO, FU
	}
	Rank title;

	protected String lastName;
	protected String firstName;
	protected String idNum;
	protected char sex;
	protected Calendar calendar = new GregorianCalendar();
	private Education facultyDegree = new Education();
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default faculty constructor
	 */
	Faculty(){
		super();
	}
	/**
	 * The normal faculty constructor
	 * @param nLastName The faculty's last name
	 * @param nFirstName The faculty's first name
	 * @param nIDnum The faculty's ID Number
	 * @param nSex The faculty's sex
	 * @param nCalendar The faculty member's birth day
	 * @param nTitle The rank of the faculty member
	 * @param nEducation The education the faculty member has
	 */
	Faculty(String nLastName, String nFirstName, String nIDnum, char nSex, Calendar nCalendar, Rank nTitle, Education nEducation) {
		lastName = nLastName;
		firstName = nFirstName;
		idNum = nIDnum;
		sex = nSex;
		calendar = nCalendar;

		title = nTitle;
		facultyDegree = nEducation;
	}
	public void setTitle(Rank nTitle) {
		title = nTitle;
	}
	public Rank getTitle() {
		return title;
	}
	public void setEducation(Education nEducation)
	{
		facultyDegree = nEducation;
	}
	public Education getEducation() {
		return facultyDegree;
	}
	/**
	 * Print out the faculty's information
	 */
	public String toString() {
		
		switch (title) {
		case AS:
			return "ID Employee number : " + idNum +
					"\nLast Name: " + lastName + 
					"\nFirst Name: " + firstName +
					"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100) + 
					"\nAssitant Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
		case AO:
			return "ID Employee number : " + idNum +
					"\nLast Name: " + lastName + 
					"\nFirst Name: " + firstName +
					"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100) + 
					"\nAssociate Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
		case FU:
			return "ID Employee number : " + idNum +
					"\nLast Name: " + lastName + 
					"\nFirst Name: " + firstName +
					"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100) + 
					"\nFull Time Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
			
		default:
			return "";
		}
	}
	/**
	 * Creates a deep copy of the Faculty object
	 */
	public Object clone() throws CloneNotSupportedException
	{
		Faculty f = (Faculty) super.clone();
		
		setLastName(f.getLastName());
		setFirstName(f.getFirstName());
		setIdNum(f.getIdNum());
		setSex(f.getSex());
		setCalendar(f.getCalendar());
		setTitle(f.getTitle());
		setEducation(f.getEducation());
		
		return f;
	}
	
	@Override
	/**
	 * Returns the monthly earnings of the faculty member
	 */
	public double monthlyEarning() {
		switch (title) {
		case AS:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY;
		case AO:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY * 1.5;
		case FU:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY * 2;
			
		default:
			return 0;
		}
	}
	/**
	 * Modifies the employee
	 */
	@Override
	public void modifyEmployee(Scanner scan) {
		// TODO Auto-generated method stub
		System.out.println("Enter last name");
		this.lastName = scan.next();
		System.out.println("Enter first name");
		this.firstName = scan.next();
		System.out.println("Enter ID number");
		this.idNum = scan.next();
		System.out.println("Enter sex");
		this.sex = scan.next().charAt(0);
		Calendar cal = Calendar.getInstance();
		System.out.println("Enter birth year");
		int year = scan.nextInt();
		System.out.println("Enter birth month");
		int month = scan.nextInt();
		System.out.println("Enter birthday");
		int day = scan.nextInt();
		cal.set(year, month, day);
		this.calendar = cal;
		boolean correctTitle = false;
		while(!correctTitle) {
			System.out.println("Set Title");
			String title = scan.next();
			if (title.equalsIgnoreCase("AS"))
			{
				this.title = Rank.AS;
				correctTitle = true;
			}
			else if(title.equalsIgnoreCase("AO"))
			{
				this.title = Rank.AO;
				correctTitle = true;
			}
			else if(title.equalsIgnoreCase("FU"))
			{
				this.title = Rank.FU;
				correctTitle = true;
			}
			else
				System.out.println("Invalid choice try again");
		}
		System.out.println("Set Degree");
		String degree = scan.next();
		System.out.println("Set Major");
		String major = scan.next();
		System.out.println("How many researchers");
		int researchers = scan.nextInt();
		this.facultyDegree = new Education(degree, major, researchers);
	}
	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return firstName;
	}
	@Override
	public void setFirstName(String nFirstName) {
		// TODO Auto-generated method stub
		firstName = nFirstName;
	}
	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return lastName;
	}
	@Override
	public void setLastName(String nLastName) {
		// TODO Auto-generated method stub
		lastName = nLastName;
	}
	@Override
	public String getIdNum() {
		// TODO Auto-generated method stub
		return idNum;
	}
	@Override
	public void setIdNum(String nId) {
		// TODO Auto-generated method stub
		idNum = nId;
	}
	@Override
	public char getSex() {
		// TODO Auto-generated method stub
		return sex;
	}
	@Override
	public void setSex(char nSex) {
		// TODO Auto-generated method stub
		sex = nSex;
	}
	@Override
	public Calendar getCalendar() {
		// TODO Auto-generated method stub
		return calendar;
	}
	@Override
	public void setCalendar(Calendar nCalendar) {
		// TODO Auto-generated method stub
		calendar = nCalendar;
	}

}
	
