package project1;

public class ChairFacultyDecorator extends FacultyDecorator{

	FacultyDecorator cfd;
	
	public ChairFacultyDecorator(Faculty decoratedFaculty) {
		super(decoratedFaculty);
		// TODO Auto-generated constructor stub
	}
	
	public String toString() {
		return "Head Chair: \n" + cfd.toString();
	}

}
