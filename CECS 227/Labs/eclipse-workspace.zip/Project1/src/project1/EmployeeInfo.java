package project1;

/**
 * This is the default info given to employees
 * 
 * @author alexb
 *
 */
interface EmployeeInfo {
	final double FACULITY_MONTHLY_SALARY = 5000.00;
	final int STAFF_MONTHLY_HOURS_WORKED = 150;
}
