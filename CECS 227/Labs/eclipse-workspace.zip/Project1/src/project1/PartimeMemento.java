package project1;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class PartimeMemento {
	protected String lastName;
	protected String firstName;
	protected String idNum;
	protected char sex;
	protected Calendar calendar = new GregorianCalendar();
	protected double hourlyRate;
	private int hoursWorked;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	
	/**
	 * The regular Partime constructor
	 * @param nLastName The part time worker's last name
	 * @param nFirstName The part time worker's first name
	 * @param nIDNum The part time worker's ID number
	 * @param nSex The part time worker's sex
	 * @param nCalendar The part time worker's birthday
	 * @param nHourlyRate The part time worker's pay per hour
	 * @param nHoursWorked The part time worker's weekly hours
	 */
	public PartimeMemento(String nLastName, String nFirstName, String nIDNum, char nSex, Calendar nCalendar, double nHourlyRate, int nHoursWorked) {
		lastName = nLastName;
		firstName = nFirstName;
		idNum = nIDNum;
		sex = nSex;
		calendar = nCalendar;
		hourlyRate = nHourlyRate;
		hoursWorked = nHoursWorked;
	}
	/**
	 * This returns the part time worker's hours per week
	 * @return Returns the part time worker's hours per week
	 */
	public int getHoursWorked() {
		return hoursWorked;
	}
	/**
	 *  This sets the part time worker's hours per week
	 * @param nHoursWorked The hours the worker had this week
	 */
	public void setHoursWorked(int nHoursWorked) {
		hoursWorked = nHoursWorked;
	}
	/**
	 * Prints out the part time worker's information
	 */
	public String toString() {
		return "ID Employee number : " + idNum +
				"\nLast Name: " + lastName + 
				"\nFirst Name: " + firstName +
				"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100) +
				"\nHours works per month: " + getHoursWorked() +
				"\nMonthy Salary: $" + df2.format(monthlyEarning());
	}
	/**
	 * This sets the staff member's hourly rate
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public void setHourlyRate(double nHourlyRate) {
		hourlyRate = nHourlyRate;
	}
	/**
	 * This returns the staff member's hourly rate
	 * @return Returns the staff member's hourly rate
	 */
	public double getHourlyRate() {
		return hourlyRate;
	}
	
	/**
	 * Returns the monthly earnings of the part time worker
	 */
	public double monthlyEarning() {
		return getHourlyRate() * hoursWorked * 4;
	}
	public String getFirstName() {
		// TODO Auto-generated method stub
		return firstName;
	}
	public void setFirstName(String nFirstName) {
		// TODO Auto-generated method stub
		firstName = nFirstName;
	}
	public String getLastName() {
		// TODO Auto-generated method stub
		return lastName;
	}
	public void setLastName(String nLastName) {
		// TODO Auto-generated method stub
		lastName = nLastName;
	}
	public String getIdNum() {
		// TODO Auto-generated method stub
		return idNum;
	}
	public void setIdNum(String nId) {
		// TODO Auto-generated method stub
		idNum = nId;
	}
	public char getSex() {
		// TODO Auto-generated method stub
		return sex;
	}
	public void setSex(char nSex) {
		// TODO Auto-generated method stub
		sex = nSex;
	}
	public Calendar getCalendar() {
		// TODO Auto-generated method stub
		return calendar;
	}
	public void setCalendar(Calendar nCalendar) {
		// TODO Auto-generated method stub
		calendar = nCalendar;
	}
}
