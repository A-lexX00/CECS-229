package project1;

public class AdminFacultyDecorator extends FacultyDecorator{

	FacultyDecorator afd;
	
	public AdminFacultyDecorator(Faculty decoratedFaculty) {
		super(decoratedFaculty);
		// TODO Auto-generated constructor stub
	}
	
	public String toString() {
		return "System's Admin: \n" + afd.toString();
	}
}
