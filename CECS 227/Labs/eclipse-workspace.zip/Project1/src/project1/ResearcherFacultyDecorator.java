package project1;

public class ResearcherFacultyDecorator extends FacultyDecorator{

	FacultyDecorator rfd;
	
	public ResearcherFacultyDecorator(Faculty decoratedFaculty) {
		super(decoratedFaculty);
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Research Director: \n" + rfd.toString();
	}
}
