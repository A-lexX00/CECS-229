package project1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;



public class EmployeeFactory implements Serializable{
	public ArrayList<Employee> empFact= new ArrayList<Employee>();
	
	public Employee getEmployee(String employeeType) {
		if (employeeType.equalsIgnoreCase("FACULTY"))
			return new Faculty();
		
		else if (employeeType.equalsIgnoreCase("STAFF"))
			return new Staff();
		
		else if (employeeType.equalsIgnoreCase("PARTIME"))
			return new Partime();
		
		return null;
	}
	
	public void addEmployee(Scanner scanner) throws FileNotFoundException, ClassNotFoundException, IOException {

		boolean quit = false;
		while(!quit)
		{
			System.out.println("What employee are you adding to the list? ");
			System.out.println("Hit 1 for Faculty, 2 for Partime, 3 for Staff\nand any oher number to quit");
			int choice = scanner.nextInt();
			Employee emp = null;
			switch (choice) {
			case 1:
				 emp = new EmployeeFactory().getEmployee("Faculty");
				 emp.modifyEmployee(scanner);
				 empFact.add(emp);
				 break;
			case 2:
				 emp = new EmployeeFactory().getEmployee("Partime");
				 emp.modifyEmployee(scanner);
				 empFact.add(emp);
				 break;
			case 3:
				 emp = new EmployeeFactory().getEmployee("Staff");
				 emp.modifyEmployee(scanner);
				 empFact.add(emp);
				 break;
			default:
				quit = true;
				break;
				 
			}
		}
	}
}
