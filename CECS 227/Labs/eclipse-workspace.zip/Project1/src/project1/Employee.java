package project1;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

/** The class Employee creates an Employee object to store employee data
 * 
 * @author alexb
 */

public interface Employee {
	
	public abstract String getFirstName();
	public abstract void setFirstName(String nFirstName);
	public abstract String getLastName();
	public abstract void setLastName(String nLastName);
	public abstract String getIdNum();
	public abstract void setIdNum(String nId);
	public abstract char getSex();
	public abstract void setSex(char nSex);
	public abstract Calendar getCalendar();
	public abstract void setCalendar(Calendar nCalendar);

	/**
	/**
	 * This abstract method returns the employee's monthly earnings
	 * @return The employee's earnings
	 */
	public abstract double monthlyEarning();
	/**
	 * This abstract method modifies employees
	 */
	public abstract void modifyEmployee(Scanner scan);
}
