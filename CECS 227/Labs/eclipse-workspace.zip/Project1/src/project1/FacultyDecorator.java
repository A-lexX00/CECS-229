package project1;

public class FacultyDecorator extends Faculty{
	public Faculty decoratedFaculty;
	
	public FacultyDecorator(Faculty decoratedFaculty) {
		this.decoratedFaculty = decoratedFaculty;
	}
	
	public String toString() {
		return decoratedFaculty.toString();
	}
}
