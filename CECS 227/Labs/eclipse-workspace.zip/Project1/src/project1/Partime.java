package project1;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.io.Serializable;
import java.text.DecimalFormat;
/**
 * The class Partime creates a part time worker which is extended
 * from staff to store Partime data
 * @author alexb
 *
 */
public class Partime implements Employee, Serializable{
	protected String lastName;
	protected String firstName;
	protected String idNum;
	protected char sex;
	protected Calendar calendar = new GregorianCalendar();
	protected double hourlyRate;
	private int hoursWorked;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default Partime constructor
	 */
	public Partime() {
		super();
		hoursWorked = 0;
	}
	/**
	 * The regular Partime constructor
	 * @param nLastName The part time worker's last name
	 * @param nFirstName The part time worker's first name
	 * @param nIDNum The part time worker's ID number
	 * @param nSex The part time worker's sex
	 * @param nCalendar The part time worker's birthday
	 * @param nHourlyRate The part time worker's pay per hour
	 * @param nHoursWorked The part time worker's weekly hours
	 */
	public Partime(String nLastName, String nFirstName, String nIDNum, char nSex, Calendar nCalendar, double nHourlyRate, int nHoursWorked) {
		lastName = nLastName;
		firstName = nFirstName;
		idNum = nIDNum;
		sex = nSex;
		calendar = nCalendar;
		hourlyRate = nHourlyRate;
		hoursWorked = nHoursWorked;
	}
	/**
	 * This returns the part time worker's hours per week
	 * @return Returns the part time worker's hours per week
	 */
	public int getHoursWorked() {
		return hoursWorked;
	}
	/**
	 *  This sets the part time worker's hours per week
	 * @param nHoursWorked The hours the worker had this week
	 */
	public void setHoursWorked(int nHoursWorked) {
		hoursWorked = nHoursWorked;
	}
	/**
	 * Prints out the part time worker's information
	 */
	public String toString() {
		return "ID Employee number : " + idNum +
				"\nLast Name: " + lastName + 
				"\nFirst Name: " + firstName +
				"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100) +
				"\nHours works per month: " + getHoursWorked() +
				"\nMonthy Salary: $" + df2.format(monthlyEarning());
	}
	/**
	 * This sets the staff member's hourly rate
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public void setHourlyRate(double nHourlyRate) {
		hourlyRate = nHourlyRate;
	}
	/**
	 * This returns the staff member's hourly rate
	 * @return Returns the staff member's hourly rate
	 */
	public double getHourlyRate() {
		return hourlyRate;
	}
	@Override
	/**
	 * Returns the monthly earnings of the part time worker
	 */
	public double monthlyEarning() {
		return getHourlyRate() * hoursWorked * 4;
	}
	/**
	 * Modifies the employee
	 */
	@Override
	public void modifyEmployee(Scanner scan) {
		// TODO Auto-generated method stub
		System.out.println("Enter last name");
		String lName = scan.next();
		this.lastName = lName;
		System.out.println("Enter first name");
		this.firstName = scan.next();
		System.out.println("Enter ID number");
		this.idNum = scan.next();
		System.out.println("Enter sex");
		this.sex = scan.next().charAt(0);
		Calendar cal = Calendar.getInstance();
		System.out.println("Enter birth year");
		int year = scan.nextInt();
		System.out.println("Enter birth month");
		int month = scan.nextInt();
		System.out.println("Enter birthday");
		int day = scan.nextInt();
		cal.set(year, month, day);
		this.calendar = cal;
		System.out.println("Enter hourly rate");
		this.hourlyRate = scan.nextDouble();
		System.out.println("Enter hours worked");
		this.hoursWorked = scan.nextInt();
	}
	
	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return firstName;
	}
	@Override
	public void setFirstName(String nFirstName) {
		// TODO Auto-generated method stub
		firstName = nFirstName;
	}
	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return lastName;
	}
	@Override
	public void setLastName(String nLastName) {
		// TODO Auto-generated method stub
		lastName = nLastName;
	}
	@Override
	public String getIdNum() {
		// TODO Auto-generated method stub
		return idNum;
	}
	@Override
	public void setIdNum(String nId) {
		// TODO Auto-generated method stub
		idNum = nId;
	}
	@Override
	public char getSex() {
		// TODO Auto-generated method stub
		return sex;
	}
	@Override
	public void setSex(char nSex) {
		// TODO Auto-generated method stub
		sex = nSex;
	}
	@Override
	public Calendar getCalendar() {
		// TODO Auto-generated method stub
		return calendar;
	}
	@Override
	public void setCalendar(Calendar nCalendar) {
		// TODO Auto-generated method stub
		calendar = nCalendar;
	}
}
