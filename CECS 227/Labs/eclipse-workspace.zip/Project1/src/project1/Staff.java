package project1;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.io.Serializable;
import java.text.DecimalFormat;
/**
 * This creates a staff member which is extended from an employee
 * to store staff data
 * @author alexb
 *
 */
public class Staff implements Employee, Serializable{
	protected String lastName;
	protected String firstName;
	protected String idNum;
	protected char sex;
	protected Calendar calendar = new GregorianCalendar();
	protected double hourlyRate;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default staff constructor
	 */
	public Staff() {
		super();
		hourlyRate = 0;
	}
	/**
	 * The regular staff constructor
	 * @param nLastName The staff member's last name
	 * @param nFirstName The staff member's first name
	 * @param nIDNum The staff member's ID number
	 * @param nSex The staff member's sex
	 * @param nCalendar The staff member's birthday
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public Staff(String nLastName, String nFirstName, String nIDNum, char nSex, Calendar nCalendar, double nHourlyRate) {
		lastName = nLastName;
		firstName = nFirstName;
		idNum = nIDNum;
		sex = nSex;
		calendar = nCalendar;
		hourlyRate = nHourlyRate;
	}
	/**
	 * This sets the staff member's hourly rate
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public void setHourlyRate(double nHourlyRate) {
		hourlyRate = nHourlyRate;
	}
	/**
	 * This returns the staff member's hourly rate
	 * @return Returns the staff member's hourly rate
	 */
	public double getHourlyRate() {
		return hourlyRate;
	}
	/**
	 * This prints out the staff member's information
	 */
	public String toString() {
		return "ID Employee number : " + idNum +
				"\nLast Name: " + lastName + 
				"\nFirst Name: " + firstName +
				"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100)
				+"\nFull Time"
				+ "\nMonthly Salary: $" + df2.format(monthlyEarning());
	}
	
	/**
	 * Modifies the employee
	 */
	@Override
	public void modifyEmployee(Scanner scan) {
		System.out.println("Enter last name");
		this.lastName = scan.next();
		System.out.println("Enter first name");
		this.firstName = scan.next();
		System.out.println("Enter ID number");
		this.idNum = scan.next();
		System.out.println("Enter sex");
		this.sex = scan.next().charAt(0);
		Calendar cal = Calendar.getInstance();
		System.out.println("Enter birth year");
		int year = scan.nextInt();
		System.out.println("Enter birth month");
		int month = scan.nextInt();
		System.out.println("Enter birthday");
		int day = scan.nextInt();
		cal.set(year, month, day);
		this.calendar = cal;
		System.out.println("Enter hourly rate");
		this.hourlyRate = scan.nextDouble();
	}
	/**
	 * This returns the staff member's monthly earnings
	 */
	@Override
	public double monthlyEarning() {
		return hourlyRate * 160;
	}
	
	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return firstName;
	}
	@Override
	public void setFirstName(String nFirstName) {
		// TODO Auto-generated method stub
		firstName = nFirstName;
	}
	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return lastName;
	}
	@Override
	public void setLastName(String nLastName) {
		// TODO Auto-generated method stub
		lastName = nLastName;
	}
	@Override
	public String getIdNum() {
		// TODO Auto-generated method stub
		return idNum;
	}
	@Override
	public void setIdNum(String nId) {
		// TODO Auto-generated method stub
		idNum = nId;
	}
	@Override
	public char getSex() {
		// TODO Auto-generated method stub
		return sex;
	}
	@Override
	public void setSex(char nSex) {
		// TODO Auto-generated method stub
		sex = nSex;
	}
	@Override
	public Calendar getCalendar() {
		// TODO Auto-generated method stub
		return calendar;
	}
	@Override
	public void setCalendar(Calendar nCalendar) {
		// TODO Auto-generated method stub
		calendar = nCalendar;
	}
}
