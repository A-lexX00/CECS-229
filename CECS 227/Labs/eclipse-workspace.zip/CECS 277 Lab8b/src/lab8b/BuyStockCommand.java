package lab8b;

public class BuyStockCommand implements ICommand{

	Stock stock;
	
	public BuyStockCommand(Stock stock) {
		super();
		this.stock = stock;
	}
	@Override
	public void execute(int number) {
		// TODO Auto-generated method stub
		System.out.println("Buying stock...");
		stock.buy(number);
	}

}
