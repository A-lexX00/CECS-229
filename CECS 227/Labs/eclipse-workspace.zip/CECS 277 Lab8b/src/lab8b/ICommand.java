package lab8b;

@FunctionalInterface
public interface ICommand {
	public void execute(int number);
}
