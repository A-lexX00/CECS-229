package lab8b;

import java.util.ArrayList;
import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = 0;
		Scanner in = new Scanner(System.in);
		ArrayList<Stock> allStocks = new ArrayList<>();
		
		StockAutomation stockAuto = new StockAutomation();
		
		while(choice < 3) {
			System.out.println("Welcome to the stock market!");
			System.out.println("What would you like to do?");
			System.out.println("Hit 1 for buy, 2 for sell, 3 to quit");
			choice = in.nextInt();
			
			switch(choice) {
				case 1	: {
					System.out.println("What's the name of the stock?");
					String name = in.next();
					System.out.println("How much does it cost?");
					double price = in.nextDouble();
					System.out.println("How many stocks?");
					int quant = in.nextInt();
					
					Stock stock = new Stock(name, price);
					stockAuto.setCommand(new BuyStockCommand(stock));;
					stockAuto.buttonPressed(quant);
					
					break;
				}
				case 2	: {
					System.out.println("Whats the name of the stock?");
					String name = in.next();
					System.out.println("How much does it cost?");
					double price = in.nextDouble();
					System.out.println("How many stocks?");
					int quant = in.nextInt();
					
					Stock stock = new Stock(name, price);
					stockAuto.setCommand(new SellStockCommand(stock));;
					stockAuto.buttonPressed(quant);
					
					break;
				}
				default	: {
					System.out.println("Thank you! See you again!");
					break;
				}
			}
		}
	}
}
