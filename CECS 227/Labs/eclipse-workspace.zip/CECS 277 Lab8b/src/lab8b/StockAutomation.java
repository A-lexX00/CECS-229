package lab8b;

public class StockAutomation {
	ICommand command;
	
	public void setCommand(ICommand command) {
		this.command = command;
	}
	
	public void buttonPressed(int numOfStock) {
		command.execute(numOfStock);
	}
}
