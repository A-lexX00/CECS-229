package lab8b;

public class SellStockCommand implements ICommand{

	Stock stock;
	
	public SellStockCommand(Stock stock) {
		super();
		this.stock = stock;
	}
	
	@Override
	public void execute(int number) {
		// TODO Auto-generated method stub
		System.out.println("Selling stock...");
		stock.sell(number);
	}
	
}
