package lab3a;
/*
 * Banh, Alex
 * CECS 277
 * Professor Phuong Nguyen
 * 25 September, 2019
 */
/**
 * Sets grades and classes
 * @author alexb
 *
 */

public class Grade {
	private double gradePoint;
	private String course;
	/**
	 * Default grade constructor
	 */
	public Grade() {
		gradePoint = 0.0;
		course = "";
	}
	/**
	 * Normal grade constructor
	 * @param nGradePoint Weight of the class
	 * @param nCourse Name of class
	 */
	public Grade(double nGradePoint, String nCourse) {
		gradePoint = nGradePoint;
		course = nCourse;
	}
	/**
	 * Returns course name
	 * @return Returns course name
	 */
	public String getCourse() {
		return course;
	}
	/**
	 * Sets course name
	 * @param nCourse Course name
	 */
	public void setCourse(String nCourse) {
		course = nCourse;
	}
	/**
	 * Returns student's grade
	 * @return Returns student grade 
	 */
	public double getGradePoint() {
		return gradePoint;
	}
	/**
	 * Sets student's grade
	 * @param nGradePoint Student's grade
	 */
	public void setGradePoint(double nGradePoint) {
		gradePoint = nGradePoint;
	}
	/**
	 * Prints out the course followed by the grade
	 */
	public String toString() {
		return "Course: " + course + "\nGrade Point: " + gradePoint;
	}

}
