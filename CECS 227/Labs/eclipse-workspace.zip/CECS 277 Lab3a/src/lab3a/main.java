package lab3a;

import java.util.ArrayList;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Grade> grades = new ArrayList<Grade>(4);
		ArrayList<Grade> g = new ArrayList<Grade>();
		grades.add(0, new Grade(4.0, "Math"));
		grades.add(1, new Grade(3.0, "English"));
		grades.add(2, new Grade(4.0, "Science"));
		grades.add(3, new Grade(3.0, "History"));
		double gpa = 0;
		Student jane = new Student(gpa, grades, "Jane", "Eyre");
		gpa = jane.calcGPA();
		System.out.println(jane);
		grades.get(2).setGradePoint(1.0);
		gpa = jane.calcGPA();
		System.out.println("Jane failed Science: \n" + jane);
		grades.get(1).setCourse("English 100");
		System.out.println("Jane upgraded English: \n" + jane);
		
		
	}

}
