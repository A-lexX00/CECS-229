package lab3a;
/*
 * Banh, Alex
 * CECS 277
 * Professor Phuong Nguyen
 * 25 September, 2019
 */
import java.util.ArrayList;
/**
 * Creates a student and that stores a students grade 
 * and GPA along with their first and last name
 * @author alexb
 *
 */
public class Student {
	private double gpa;
	private ArrayList<Grade> grades;
	private String firstName;
	private String lastName;
	/**
	 * Default student constructor
	 */
	public Student() {
		gpa = 0.0;
		grades = new ArrayList<Grade>(0);
		firstName = "";
		lastName = "";
	}
	/**
	 * Regular student constructor
	 * @param nGpa Student's GPA
	 * @param nGrades ArrayList of student's classes
	 * @param nFirstName Student's first name
	 * @param nLastName Student's last name
	 */
	public Student(double nGpa, ArrayList<Grade> nGrades, String nFirstName, String nLastName) {
		gpa = nGpa;
		grades = new ArrayList<Grade>();
		for (Grade g: nGrades)
			grades.add(g);
		firstName = nFirstName;
		lastName = nLastName;
	}
	/**
	 * Returns student's GPA
	 * @return Returns GPA
	 */
	public double getGpa() {
		return gpa;
	}
	/**
	 * Sets a student's GPA
	 * @param nGpa Student's GPA
	 */
	public void setGpa(double nGpa) {
		gpa = nGpa;
	}
	/**
	 * Returns all the student's classes
	 * @return Returns classes
	 */
	public ArrayList<Grade> getGrade() {
		return grades;
	}
	/**
	 * Sets all the student's classes
	 * @param nGrades ArrayList of all the student's classes
	 */
	public void setGrade(ArrayList<Grade> nGrades) {
		grades = new ArrayList<Grade>();
		for (Grade g:nGrades)
			grades.add(g);
	}
	/**
	 * Returns the student's first name
	 * @return Returns first name
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * Sets the student's first name
	 * @param nFirstName Student's First Name
	 */
	public void setFirstName(String nFirstName) {
		firstName = nFirstName;
	}
	/**
	 * Returns a student's last name
	 * @return Return's last name
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * Sets the student's last name
	 * @param nLastName Student's Last Name
	 */
	public void setLastName(String nLastName) {
		lastName = nLastName;
	}
	/**
	 * Calculates and returns a student's GPA
	 * @return Student's GPA
	 */
	public double calcGPA() {
		int classes = 0;
		for (Grade g : grades) {
			gpa += g.getGradePoint();
			classes++;
		}
		gpa /= classes;
		return gpa;
	}
	/**
	 * Prints a student's last name followed by their first name
	 * followed by their GPA then all their classes
	 */
	public String toString() {
		String classes = "";    
		for (Grade g: grades)
		{
			classes += g.toString() + '\n';
		}
		return lastName + ", " + firstName 
				+ "\nGPA: " + gpa 
				+ "\nClasses: " + classes;
	}
}
