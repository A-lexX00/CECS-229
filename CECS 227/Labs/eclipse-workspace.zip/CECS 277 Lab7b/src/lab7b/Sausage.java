package lab7b;

public class Sausage extends PizzaDecorator{
	public Sausage(Pizza newPizza) {
		super(newPizza);
	}
	
	public String bakePizza() {
		return super.bakePizza() + " add Sausage";
	}
}
