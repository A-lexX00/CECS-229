package lab7b;

public class Pepperoni extends PizzaDecorator{
	public Pepperoni(Pizza newPizza) {
		super(newPizza);
	}
	
	public String bakePizza() {
		return super.bakePizza() + " add Pepperoni";
	}
}
