package lab7b;

public class PizzaDecorator implements Pizza{
	Pizza pizza;
	String allToppings = "Pizza";
	
	public PizzaDecorator(Pizza newPizza) {
		pizza = newPizza;
	}

	public String bakePizza() {
		return pizza.bakePizza();
	}
	
	public String getToppings() {
		return allToppings;
	}
}
