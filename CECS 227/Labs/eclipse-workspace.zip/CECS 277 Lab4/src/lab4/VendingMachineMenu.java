package lab4;

import java.util.Scanner;
/**
 * Menu for our vending machine
 * @author alexb
 *
 */
public class VendingMachineMenu {
	private Scanner in;
	private static Coin[] coins = 
		{ new Coin (0.05, "nickel"),
		  new Coin (0.1, "dime"),
		  new Coin (0.25, "quater"),
		  new Coin (1.0, "dollar")
		};
	/**
	 * Runs our vending machine function so people can buy stuff
	 * @param m The vending machine we buy from
	 * @throws PriceException Not enough cash
	 */
	void run(VendingMachine m) throws PriceException {
		boolean stop = false;
		while(!stop) {
			System.out.println("S)how products I)nsert coin B)uy A)dd product R)emove coins Q)uit");
			in = new Scanner(System.in);
			char c = in.next().charAt(0);
			if(Character.toLowerCase(c) == 's')
			{
				for(int i = 0; i < m.productList.size(); i++)
					System.out.println(m.productList.get(i).toString());
			}
			else if(Character.toLowerCase(c) == 'i')
			{
				for(int i = 0; i < coins.length; i++) {
					System.out.println(coins[i].toString());
				}
				in = new Scanner(System.in);
				c = in.next().charAt(0);
				if(Character.toLowerCase(c) == 'a')
					m.currentCoins.addCoin(coins[0]);
				else if (Character.toLowerCase(c) == 'b')
					m.currentCoins.addCoin(coins[1]);
				else if (Character.toLowerCase(c) == 'c')
					m.currentCoins.addCoin(coins[2]);
				else if (Character.toLowerCase(c) == 'd')
					m.currentCoins.addCoin(coins[3]);
			}
			else if(Character.toLowerCase(c) == 'b')
			{
				for(int i = 0; i < m.productList.size(); i++) {
					System.out.println(m.productList.get(i).toString());
				}
				c = in.next().charAt(0);
				
				if(Character.toLowerCase(c) == 'a') {
					m.buyProduct(m.productList.get(0));
					System.out.println("Purchased: " + m.productList.get(0).toString());
				}
				else if(Character.toLowerCase(c) == 'b') {
					m.buyProduct(m.productList.get(1));
					System.out.println("Purchased: " + m.productList.get(1).toString());
				}
				else if(Character.toLowerCase(c) == 'c') {
					m.buyProduct(m.productList.get(2));
					System.out.println("Purchased: " + m.productList.get(2).toString());
				}
				else if(Character.toLowerCase(c) == 'd') {
					m.buyProduct(m.productList.get(3));
					System.out.println("Purchased: " + m.productList.get(3).toString());
				}

				System.out.println("Change: $" + m.change +'\n' + "Remaining Items: " + m.products.size());
				m.change = 0;
			}
			else if(Character.toLowerCase(c) == 'a')
			{
				System.out.println("Description:");
				String descr = in.next();
				System.out.println("Price:");
				double price = in.nextDouble();
				System.out.println("Quantity:");
				int quant = in.nextInt();
				Product p = new Product(descr, price);
				m.addProduct(p, quant);
			}
			else if(Character.toLowerCase(c) == 'r')
			{
				System.out.println("Removed: $" + m.coins.getValue(m.coins));
				m.currentCoins.removeAllCoins(m.coins);
			}
			else if(Character.toLowerCase(c) == 'q')
			{
				stop = true;
			}
			else
				System.out.println("Invalid input");
		}
	}

}
