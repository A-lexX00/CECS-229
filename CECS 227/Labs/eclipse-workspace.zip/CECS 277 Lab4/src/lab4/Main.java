package lab4;

public class Main {

	public static void main(String[] args) throws PriceException {
		// TODO Auto-generated method stub
		VendingMachine m = new VendingMachine();
		VendingMachineMenu menu = new VendingMachineMenu();
			menu.run(m);

	}

}
