package lab4;
/**
 * Creates Coins to store value
 * @author alexb
 *
 */
public class Coin {
	double value;
	String name;
	/**
	 * Default coin constructor
	 */
	public Coin() {
		value = 0.0;
		name = "";
	}
	/**
	 * Normal coin constructor
	 * @param nValue Worth of coin
	 * @param nName Name of coin
	 */
	public Coin(double nValue, String nName) {
		value = nValue;
		name = nName;
	}
	/**
	 * Prints out coin name and value
	 */
	public String toString() {
		return name + " @ " + value;
	}
	/**
	 * Returns coin's value
	 * @return Return value
	 */
	public double getValue() {
		return value;
	}

}
