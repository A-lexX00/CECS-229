package lab8c;

public class Calculator {
	private int x;
	private int y;
	private char operand;
	private int solution;
	
	public Calculator() {
		this.x = 0;
		this.y = 0;
		this.operand = '+';
		this.solution = 0;
	}
	
	public Calculator(int x, int y, char operand) {
		this.x = x;
		this.y = y;
		this.operand = operand;
		calc(operand);
	}
	
	public void setX(int x) {
		this.x = x;
		calc(operand);
	}
	
	public void setY(int y) {
		this.y = y;
		calc(operand);
	}
	
	public void setOp(char op) {
		this.operand = op;
		calc(operand);
	}
	
	public CalculatorMemento createMemento() {
		CalculatorMemento m = new CalculatorMemento(x, y, operand, solution);
		return m;
	}
	
	public void restore(CalculatorMemento m) {
		this.x = m.getX();
		this.y = m.getY();
		this.operand = m.getOperand();
		this.solution = m.getSolution();
	}
	
	public void calc(char op){
		operand = op;
		
        switch(operand) 
        { 
            case('+'): {
            	this.solution = x + y;
                break; 
            }
            case('-'): {
                this.solution = x - y;
                break; 
            }
            case('*'): {
                this.solution = x * y;
                break; 
            }
            case('/'): {
            	this.solution = x / y;
                break; 
            }
         } 
	}
 
	public String toString() {
		return x + " " + operand + " " + y + " = " + solution;
	}
}
