package lab8c;

import java.util.Scanner;

public class MainCaretaker {
	public static void main(String[] args) {
	
		int choice = 0;
		Scanner in = new Scanner(System.in);
		Calculator calculator = new Calculator();
		CalculatorMemento CalcMemento = calculator.createMemento();
		
		while(choice < 3) {
			System.out.println("Calculator");
			System.out.println("What would you like to do?");
			System.out.println("Hit 1 calculate a solution, 2 to recall last equation, 3 to quit");
			choice = in.nextInt();
			switch(choice) {
			case 1	: {
				System.out.println("Enter x");
				int x = in.nextInt();
				System.out.println("Enter y");
				int y = in.nextInt();
				System.out.println("Enter operand");
				char op = in.next().charAt(0);

				calculator = new Calculator(x,y,op);
				System.out.println(calculator);
				System.out.println("Store equation? (Y/N)");
				char yesOrNo = in.next().toUpperCase().charAt(0);
				if(yesOrNo == 'Y' )
					CalcMemento = calculator.createMemento();
				
				break;
			}
			case 2	: {
				System.out.println("Recalling last equation");
				calculator.restore(CalcMemento);
				System.out.println(calculator);
				break;
			}
			default	: {
				System.out.println("Thank you! See you again!");
				break;
			}
			}
		}
	}
}
