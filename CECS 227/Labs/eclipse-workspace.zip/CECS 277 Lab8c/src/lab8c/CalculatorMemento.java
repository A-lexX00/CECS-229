package lab8c;

public class CalculatorMemento {
	private int x;
	private int y;
	private char operand;
	private int solution;
	
	public CalculatorMemento(int x, int y, char operand, int solution) {
		this.x = x;
		this.y = y;
		this.operand = operand;
		this.solution = solution;
	}
	
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public char getOperand() {
		return operand;
	}
	public void setOperand(char operand) {
		this.operand = operand;
	}
	
	public int getSolution() {
		return solution;
	}
}
