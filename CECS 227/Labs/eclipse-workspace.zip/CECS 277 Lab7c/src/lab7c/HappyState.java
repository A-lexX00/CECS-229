package lab7c;

public class HappyState implements State{
	public HappyState() {
		
	}
	
	public void doAction() {
		System.out.println("Robot Talk & Cook");
	}
}
