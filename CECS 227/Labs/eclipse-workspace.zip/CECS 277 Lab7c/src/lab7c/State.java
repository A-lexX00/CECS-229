package lab7c;

public interface State {
	public abstract void doAction();
}
