package lab1;

public class Rational {

}
