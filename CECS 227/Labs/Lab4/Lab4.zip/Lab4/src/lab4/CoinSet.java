package lab4;

import java.util.ArrayList;
/**
 * Stores multiple coins
 * @author alexb
 *
 */

public class CoinSet {
	private ArrayList<Coin> cSet;
	/**
	 * Default coin set constructor
	 */
	public CoinSet() {
		cSet = new ArrayList<Coin>(0);
	}
	/**
	 * Returns size of coin set
	 * @return Returns size of set
	 */
	public int getSize() {
		return cSet.size();
	}
	/**
	 * Adds a coin to the list
	 * @param c Coin to be added
	 */
	public void addCoin(Coin c) {
		cSet.add(c);
	}
	/**
	 * Adds all coins from a list to another list
	 * @param manyCoins A set of other coins
	 */
	public void addCoins(CoinSet manyCoins) {
		cSet.addAll(manyCoins.cSet);
	}
	/**
	 * Returns values of all the coins totaled
	 * @param userCoins List of coins being added
	 * @return Returns the total value of the coins
	 */
	public double getValue(CoinSet userCoins) {
		double total = 0;
		for (int i = 0; i < userCoins.getSize(); i++) {
			 total += userCoins.cSet.get(i).getValue();
		}
		return total;
	}
	/**
	 * Clears all the coins from a coin set
	 * @param set The set of coins to be cleared
	 */
	public void removeAllCoins(CoinSet set) {
		set.cSet.clear();
	}

}
