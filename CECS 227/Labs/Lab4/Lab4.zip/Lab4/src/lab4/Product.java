package lab4;
/**
 * Stores the products of the vending machine
 * @author alexb
 *
 */
public class Product {
	private String description;
	private double price;
	/**
	 * Default product constructor
	 */
	public Product() {
		description = "";
		price = 0.0;
	}
	/**
	 * Regular product constructor
	 * @param nDescription Name of product
	 * @param nPrice Cost of product
	 */
	public Product(String nDescription, double nPrice) {
		description = nDescription;
		price = nPrice;
	}
	/**
	 * Returns product name
	 * @return Returns product name
	 */
	public String getSnack() {
		return description;
	}
	/**
	 * Set product name
	 * @param nDescription Product name
	 */
	public void setSnack(String nDescription) {
		description = nDescription;
	}
	/**
	 * Returns product price
	 * @return Return product price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * Set product price
	 * @param nPrice Product price
	 */
	public void setPrice(double nPrice) {
		price = nPrice;
	}
	/**
	 * Compares two products to see if they are equal
	 * @param other Product to be compared
	 * @return True if equal
	 */
	public boolean equals(Product other) {
		return ((description == other.description) && (price == other.price));
	}
	/**
	 * Prints out product name and price
	 */
	public String toString() {
		return description + " @ $" + price;
	}

}
