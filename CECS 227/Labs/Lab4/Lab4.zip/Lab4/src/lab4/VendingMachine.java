package lab4;
/*
 * Banh, Alex
 * CECS 277
 * Professor Phuong Nguyen
 * 2 October, 2019
 */
import java.util.ArrayList;
/**
 * Stores multiple products and cash in the machine
 * @author alexb
 *
 */

public class VendingMachine {
	ArrayList<Product> products;
	public CoinSet coins;
	public CoinSet currentCoins;
	
	ArrayList<Product> productList;
	double change;
	/**
	 * Default vending machine constructor
	 */
	public VendingMachine() {
		products = new ArrayList<Product>(0);
		coins = new CoinSet();
		currentCoins = new CoinSet();
		productList = new ArrayList<Product>(0);
		change = 0;
	}
	/**
	 * Add a new product to the vending machine
	 * @param p The product to add
	 * @param quantity How much of the product to add
	 */
	public void addProduct(Product p, int quantity) {
		for(int i = 0; i < quantity; i++)
			products.add(p);
		
		if (!productList.contains(p))
			productList.add(p);
	}
	/**
	 * Returns a product if you have enough cash
	 * @param p Product to buy
	 * @return Return the product you bought
	 * @throws PriceException Not enough cash to buy it
	 */
	public Product buyProduct(Product p) throws PriceException {
		
			Product tempProduct = null;
			for (int i = 0; i < products.size(); i++) {
				if(products.get(i).equals(p))
				{
					if (currentCoins.getValue(currentCoins) < products.get(i).getPrice())
					{
						System.out.println("Insufficent money");
						break;
					}
					else
					{
						tempProduct = products.get(i);	
						products.remove(i);
						change = currentCoins.getValue(currentCoins) - tempProduct.getPrice();
						Coin cashEarned = new Coin(tempProduct.getPrice(), "Cash");
						coins.addCoin(cashEarned);
						currentCoins.removeAllCoins(currentCoins);
					
						ArrayList<Product> removedProd = new ArrayList<Product>(0); 
						removedProd.addAll(products);
						products = removedProd;
						
						if(!products.contains(tempProduct))
							productList.remove(tempProduct);
					
						break;
					}		
				}
			}
			return tempProduct;
		}

}