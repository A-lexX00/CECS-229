/* Banh, Alex
 * Professor Phuong Nguyen
 * 
 * Lab 2
 *
 * CECS 277
 * 18 September 2019
 */
package lab2;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lab2.Faculty.Rank;

public class main {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		Calendar cal3 = Calendar.getInstance();
		Calendar cal4 = Calendar.getInstance();
		Calendar cal5 = Calendar.getInstance();
		Calendar cal6 = Calendar.getInstance();
		Calendar cal7 = Calendar.getInstance();
		Calendar cal8 = Calendar.getInstance();
		Calendar cal9 = Calendar.getInstance();
		
		ArrayList<Employee> aEmployee = new ArrayList<Employee>(9);
		cal1.set(1959, 2, 23);
		aEmployee.add(new Staff("Allen", "Paita", "123", 'M', cal1, 50.0 ));
		cal2.set(1964, 7, 12);
		aEmployee.add(new Staff("Zapata", "Steven", "456", 'F', cal2, 35.0 ));
		cal3.set(1970, 6, 2);
		aEmployee.add(new Staff("Rios", "Enrique", "789", 'M', cal3, 40.0 ));
		cal4.set(1962, 4, 27);
		Education ed = new Education("Ph.D", "Engineering", 3);
		aEmployee.add(new Faculty("Johnson", "Anne", "243", 'F', cal4, Rank.FU , ed));
		cal5.set(1975, 3, 75);
		ed = new Education("Ph.D", "English", 1);
		aEmployee.add(new Faculty("Bouris", "William", "791", 'F', cal5, Rank.AS , ed));
		cal6.set(1980, 5, 22);
		ed = new Education("MS", "Physical Education", 0);
		aEmployee.add(new Faculty("Andrade", "Christopher", "623", 'F', cal6, Rank.AO , ed));
		cal7.set(1977, 8, 10);
		aEmployee.add(new Partime("Guzman", "Augusto", "455", 'F', cal7, 35.0, 30));
		cal8.set(1987, 9, 15);
		aEmployee.add(new Partime("Depirro", "Martin", "678", 'F', cal8, 30.0, 15));
		cal9.set(1988, 11, 24);
		aEmployee.add(new Partime("Aldaco", "Marque", "945", 'F', cal9, 20.0, 35));
		
		// Part a)
		/**
		 * I loop through my ArrayList and print out each of the employees
		 */
		System.out.println("Part a): ");
		for (int i = 0; i < aEmployee.size(); i++)
			System.out.println(aEmployee.get(i).toString() + '\n');
		
		// Part b)
		/**
		 * I check each of the instances of the employee to make sure they
		 * are part time employees before adding them all up
		 */
		int partTimeSal = 0;
		System.out.println("Part b): ");
		for (int i = 0; i < aEmployee.size(); i++)
			if (aEmployee.get(i) instanceof Partime)
			partTimeSal += ((Partime)aEmployee.get(i)).monthlyEarning();
		System.out.println("Total Part Time Salary: $" + partTimeSal);
		
		// Part c)
		/**
		 * I sum up all the monthly earnings of each of the employees
		 */
		int allStaffSal = 0;
		System.out.println("\nPart c): ");
		for (int i = 0; i < aEmployee.size(); i++)
			allStaffSal += aEmployee.get(i).monthlyEarning();
		System.out.println("All Staff Salary: $" + allStaffSal);
		
		// Part d)
		/**
		 * I created a new java file called SortByNumber in order to use the 
		 * 
		 * 
		 * import java.util.Comparator;

				class SortByNumber implements Comparator<Employee>{
					public int compare(Employee o1, Employee o2) {
						return o1.getIdNum().compareTo(o2.getIdNum());
						}

	
				}
		 * 
		 * Collections.sort(list, method) method to sort them all in ascending 
		 * order by ID number
		 */
		System.out.println("\nPart d): ");
		Collections.sort(aEmployee, new SortByNumber());
		System.out.print("\nSorted by Number: ");
		for (int i = 0; i < aEmployee.size(); i++)
			System.out.println(aEmployee.get(i).toString() + '\n');
		
		// Part e)
		/**
		 * I create a new java file called SortByName in order to use the
		 * 
		 * import java.util.Comparator;

			class SortByName implements Comparator<Employee>{
				public int compare(Employee o1, Employee o2) {
					return o1.getLastName().compareTo(o2.getLastName());
				}

			}
		 * Collections.sort(list, method) method to sort them all in ascending 
		 * order by last name and did Collections.reverseOrder to print it in 
		 * the descending order
		 */
		System.out.println("\nPart e): ");
		Collections.sort(aEmployee, Collections.reverseOrder(new SortByName()));
		System.out.print("\nSorted by Name: ");
		for (int i = 0; i < aEmployee.size(); i++)
			System.out.println(aEmployee.get(i).toString() + '\n');
		
		// Part f)
		/**
		 * Instructions not clear on whether or not to make a shallow or a deep
		 * copy so I made both to verify.  I used the regular cloning method to 
		 * make a shallow clone and make a deep clone method within the Faculty
		 * method with this code
		 * 
		   public Object clone() throws CloneNotSupportedException
			{
				return super.clone();
			}
		 * 
		 * in order to create a deep clone of the faculty object.
		 */
		System.out.println("\nPart f): ");
		
		Faculty fac = (Faculty) aEmployee.get(2);
		Faculty facDeepClone = (Faculty) fac.clone();
		
		System.out.println("\nOriginal Copy Education: \n"  + fac.toString());
		
		System.out.println("\nDeep Clone Education: \n"  + facDeepClone.toString());
		
		System.out.println("\n\nEdit Education in original: \n");
		Education edEdit = new Education("Masters", "Religion", 34);
		fac.setEducation(edEdit);
		System.out.println("\nOriginal Copy Education: \n"  + fac.toString() + "\n\nDeep Clone Education: \n"  + facDeepClone.toString());
		
		System.out.println("\nEdit Education in Deep Copy: \n");
		Education edEdit2 = new Education("Associate", "New Age Music", 76);
		facDeepClone.setEducation(edEdit2);
		System.out.println("\n\nOriginal Copy Education: \n"  + fac.toString() + "\n\nDeep Clone Education: \n"  + facDeepClone.toString());
		
		
		
	}

}

