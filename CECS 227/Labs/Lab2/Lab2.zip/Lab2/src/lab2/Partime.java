package lab2;

import java.util.Calendar;
import java.text.DecimalFormat;
/**
 * The class Partime creates a part time worker which is extended
 * from staff to store Partime data
 * @author alexb
 *
 */
public class Partime extends Staff{
	
	private int hoursWorked;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default Partime constructor
	 */
	public Partime() {
		super();
		hoursWorked = 0;
	}
	/**
	 * The regular Partime constructor
	 * @param nLastName The part time worker's last name
	 * @param nFirstName The part time worker's first name
	 * @param nIDNum The part time worker's ID number
	 * @param nSex The part time worker's sex
	 * @param nCalendar The part time worker's birthday
	 * @param nHourlyRate The part time worker's pay per hour
	 * @param nHoursWorked The part time worker's weekly hours
	 */
	public Partime(String nLastName, String nFirstName, String nIDNum, char nSex, Calendar nCalendar, double nHourlyRate, int nHoursWorked) {
		super(nLastName, nFirstName, nIDNum, nSex, nCalendar, nHourlyRate);
		hoursWorked = nHoursWorked;
	}
	/**
	 * This returns the part time worker's hours per week
	 * @return Returns the part time worker's hours per week
	 */
	public int getHoursWorked() {
		return hoursWorked;
	}
	/**
	 *  This sets the part time worker's hours per week
	 * @param nHoursWorked The hours the worker had this week
	 */
	public void setHoursWorked(int nHoursWorked) {
		hoursWorked = nHoursWorked;
	}
	/**
	 * Prints out the part time worker's information
	 */
	public String toString() {
		return "ID Employee number : " + super.getIdNum() +
				"\nLast Name: " + super.getLastName() + 
				"\nFirst Name: " + super.getFirstName() +
				"\nBirth date: " + super.getCalendar().get(Calendar.MONTH) + "/" + (super.getCalendar().get(Calendar.DAY_OF_MONTH)) + "/" + (super.getCalendar().get(Calendar.YEAR) % 100) +
				"\nHours works per month: " + getHoursWorked() +
				"\nMonthy Salary: $" + df2.format(monthlyEarning());
	}
	
	@Override
	/**
	 * Returns the monthly earnings of the part time worker
	 */
	public double monthlyEarning() {
		return super.getHourlyRate() * hoursWorked * 4;
	}
}
