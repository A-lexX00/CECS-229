package lab2;
/**
 * The class Education creates an Education object to store faculty information
 * @author alexb
 *
 */
public class Education {
	private String degree;
	private String major;
	private int research;
	/**
	 * The default education constructor
	 */
	public Education() {
		degree = "";
		major = "";
		research = 0;
	}
	/**
	 * The normal education constructor
	 * @param nDegree The degree they currently hold
	 * @param nMajor What they majored in
	 * @param nResearch How many people are on their research team
	 */
	public Education(String nDegree, String nMajor, int nResearch) {
		degree = nDegree;
		major = nMajor;
		research = nResearch;
	}
	/**
	 * This returns what degree they have
	 * @return Returns the degree
	 */
	public String getDegree() {
		return degree;
	}
	/**
	 * This sets the degree they have
	 * @param nDegree The degree they have
	 */
	public void setDegree(String nDegree) {
		degree = nDegree;
	}
	/**
	 * This returns what major they have
	 * @return Returns the major
	 */
	public String getMajor() {
		return major;
	}
	/**
	 * This sets the major they have
	 * @param nMajor The major they have
	 */
	public void setMajor(String nMajor) {
		major = nMajor;
	}
	/**
	 * This returns the amount of researchers they have
	 * @return Returns the amount of researchers
	 */
	public int getResearch() {
		return research;
	}
	/**
	 * This sets the amount of researchers they have
	 * @param nResearch The amount of researchers they have
	 */
	public void setResearch(int nResearch) {
		research = nResearch;
	}
}
