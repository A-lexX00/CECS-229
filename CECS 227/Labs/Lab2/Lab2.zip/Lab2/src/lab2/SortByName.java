package lab2;

import java.util.Comparator;
/**
 * Sorts the employee's by last name
 * @author alexb
 *
 */

class SortByName implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getLastName().compareTo(o2.getLastName());
	}

}
