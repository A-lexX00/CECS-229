/* Banh, Alex
 * Professor Phuong Nguyen
 * 
 * Lab 2
 *
 *CECS 277
 * 16 September 2019
 */
package lab2;

import java.util.Calendar;
import java.util.GregorianCalendar;

/** The class Employee creates an Employee object to store employee data
 * 
 * @author alexb
 */

public abstract class Employee {
	private String lastName;
	private String firstName;
	private String idNum;
	private char sex;
	private Calendar calendar = new GregorianCalendar();
	
/**
 * This is the default employee constructor	
 */
	public Employee()
	{
		lastName = "";
		firstName = "";
		idNum = "";
		sex = ' ';
		calendar.set(2000, 1, 1);
	}
/**
 * This is the normal constructor of the employee
 * @param nLastName The last name inputed
 * @param nFirstName The first name inputed
 * @param nIDnum The ID number inputed
 * @param nSex The sex of the employee
 * @param nCalendar The employee's birthday
 */
	public Employee(String nLastName, String nFirstName, String nIDnum, char nSex, Calendar nCalendar)
	{
		lastName = nLastName;
		firstName = nFirstName;
		idNum = nIDnum;
		sex = nSex;
		calendar = nCalendar;
	}
	/**
	 * This sets the first name of the employee
	 * @param nFirstName The employee's first name
	 */
	public void setFirstName(String nFirstName) {
		firstName = nFirstName;
	}
	/**
	 * This returns the employee's first name
	 * @return Returns the employee's first name
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * This sets the last name of the employee
	 * @param nLastName The employee's last name
	 */
	public void setLastName(String nLastName) {
		lastName = nLastName;
	}
	/**
	 * This returns the employee's last name
	 * @return Returns the employee's last name
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * This sets the employee's ID number
	 * @param nIDnum The employee's ID number
	 */
	public void setIdNum(String nIDnum) {
		idNum = nIDnum;
	}
	/**
	 * This returns the employee's ID number
	 * @return Returns the employee's ID number
	 */
	public String getIdNum() {
		return idNum;
	}
	/**
	 * This sets the employee's sex
	 * @param nSex The employee's sex
	 */
	public void setSex(char nSex) {
		sex = nSex;
	}
	/**
	 * This returns the employee's sex
	 * @return Returns the employee's sex
	 */
	public char getSex() {
		return sex;
	}
	/**
	 * This sets the employee's birthday
	 * @param nCalendar The employee's birthday
	 */
	public void setCalendar(Calendar nCalendar) {
		calendar = nCalendar;
	}
	/**
	 * This returns the employee's birthday
	 * @return Returns the employee's birthday
	 */
	public Calendar getCalendar() {
		return calendar;
	}
	/**
	 * This prints out the employee's information
	 */
	public String toString() {
		return "ID Employee number : " + idNum +
				"\nLast Name: " + lastName + 
				"\nFirst Name: " + firstName +
				"\nBirth date: " + calendar.get(Calendar.MONTH) + "/" + (calendar.get(Calendar.DAY_OF_MONTH)) + "/" + (calendar.get(Calendar.YEAR) % 100);
	}
	/**
	 * This abstract method returns the employee's monthly earnings
	 * @return The employee's earnings
	 */
	public abstract double monthlyEarning();
}
