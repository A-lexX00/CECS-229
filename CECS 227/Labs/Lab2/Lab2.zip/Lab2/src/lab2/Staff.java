package lab2;

import java.util.Calendar;
import java.text.DecimalFormat;
/**
 * This creates a staff member which is extended from an employee
 * to store staff data
 * @author alexb
 *
 */
public class Staff extends Employee{
	
	private double hourlyRate;
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default staff constructor
	 */
	public Staff() {
		super();
		hourlyRate = 0;
	}
	/**
	 * The regular staff constructor
	 * @param nLastName The staff member's last name
	 * @param nFirstName The staff member's first name
	 * @param nIDNum The staff member's ID number
	 * @param nSex The staff member's sex
	 * @param nCalendar The staff member's birthday
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public Staff(String nLastName, String nFirstName, String nIDNum, char nSex, Calendar nCalendar, double nHourlyRate) {
		super(nLastName, nFirstName, nIDNum, nSex, nCalendar);
		hourlyRate = nHourlyRate;
	}
	/**
	 * This sets the staff member's hourly rate
	 * @param nHourlyRate The staff member's hourly rate
	 */
	public void setHourlyRate(double nHourlyRate) {
		hourlyRate = nHourlyRate;
	}
	/**
	 * This returns the staff member's hourly rate
	 * @return Returns the staff member's hourly rate
	 */
	public double getHourlyRate() {
		return hourlyRate;
	}
	/**
	 * This prints out the staff member's information
	 */
	public String toString() {
		return super.toString() +"\nFull Time"
				+ "\nMonthly Salary: $" + df2.format(monthlyEarning());
	}
	/**
	 * This returns the staff member's monthly earnings
	 */
	@Override
	public double monthlyEarning() {
		return hourlyRate * 160;
	}

}
