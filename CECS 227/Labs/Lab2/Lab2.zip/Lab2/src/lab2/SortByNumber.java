package lab2;

import java.util.Comparator;
/**
 * Sorts the employees by ID number
 * @author alexb
 *
 */

class SortByNumber implements Comparator<Employee>{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o1.getIdNum().compareTo(o2.getIdNum());
	}

	
}
