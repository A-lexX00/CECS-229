package lab2;

import java.util.Calendar;
import java.text.DecimalFormat;

/**
 * The class Faculty creates a faulty object that is extended from 
 * Employee and is cloneable to store Faculty data
 * @author alexb
 *
 */
public class Faculty extends Employee implements Cloneable{

	public enum Rank {
		AS, AO, FU
	}
	Rank title;
	
	private Education facultyDegree = new Education();
	private static DecimalFormat df2 = new DecimalFormat("#.##");
	/**
	 * The default faculty constructor
	 */
	Faculty(){
		super();
	}
	/**
	 * The normal faculty constructor
	 * @param nLastName The faculty's last name
	 * @param nFirstName The faculty's first name
	 * @param nIDnum The faculty's ID Number
	 * @param nSex The faculty's sex
	 * @param nCalendar The faculty member's birth day
	 * @param nTitle The rank of the faculty member
	 * @param nEducation The education the faculty member has
	 */
	Faculty(String nLastName, String nFirstName, String nIDnum, char nSex, Calendar nCalendar, Rank nTitle, Education nEducation) {
		super(nLastName, nFirstName, nIDnum, nSex, nCalendar);
		title = nTitle;
		facultyDegree = nEducation;
	}
	public void setTitle(Rank nTitle) {
		title = nTitle;
	}
	public Rank getTitle() {
		return title;
	}
	public void setEducation(Education nEducation)
	{
		facultyDegree = nEducation;
	}
	public Education getEducation() {
		return facultyDegree;
	}
	/**
	 * Print out the faculty's information
	 */
	public String toString() {
		switch (title) {
		case AS:
			return super.toString() + 
					"\nAssitant Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
		case AO:
			return super.toString() + 
					"\nAssociate Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
		case FU:
			return super.toString() + 
					"\nFull Time Professor" +
					"\nMonthly Salary : $" + df2.format(monthlyEarning()) +
					"\nDegree: " + facultyDegree.getDegree() +
					"\nMajor: " + facultyDegree.getMajor() +
					"\nResearchers: " + facultyDegree.getResearch();
			
		default:
			return "";
		}
	}
	/**
	 * Creates a deep copy of the Faculty object
	 */
	public Object clone() throws CloneNotSupportedException
	{
		Faculty f = (Faculty) super.clone();
		
		setLastName(f.getLastName());
		setFirstName(f.getFirstName());
		setIdNum(f.getIdNum());
		setSex(f.getSex());
		setCalendar(f.getCalendar());
		setTitle(f.getTitle());
		setEducation(f.getEducation());
		
		return f;
	}
	
	@Override
	/**
	 * Returns the monthly earnings of the faculty member
	 */
	public double monthlyEarning() {
		switch (title) {
		case AS:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY;
		case AO:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY * 1.5;
		case FU:
			return EmployeeInfo.FACULITY_MONTHLY_SALARY * 2;
			
		default:
			return 0;
		}
	}
	
}