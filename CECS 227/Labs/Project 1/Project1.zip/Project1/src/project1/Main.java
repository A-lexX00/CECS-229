package project1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import project1.Employee;
import project1.Faculty.Rank;

public class Main {

	public static void main(String[] args) throws CloneNotSupportedException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		//Open file
		File file = new File("EmployeeList.dat");
		EmployeeFactory ef = new EmployeeFactory();
		
		Scanner scanner = new Scanner(System.in);
		
		
		if (file.length() == 0) {
			System.out.println("File is empty, generated empty map");
			ef.addEmployee(scanner);
		}
		else {
			System.out.println("Fill with data from file");
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("EmployeeList.dat"));
			ef = (EmployeeFactory) ois.readObject();
			ef.addEmployee(scanner);
		}
		//Create data
		
		scanner.close();
		
		// Part a)
		/**
		 * I loop through my ArrayList and print out each of the employees
		 */
		System.out.println("Part a): ");
		for (int i = 0; i < ef.empFact.size(); i++)
			System.out.println(ef.empFact.get(i).toString() + '\n');
		
		//Save data
		
		ObjectOutputStream oos1 = new ObjectOutputStream(new FileOutputStream("EmployeeList.dat"));
        oos1.writeObject(ef);
        oos1.close();
	}

}
