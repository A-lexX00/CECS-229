package lab5;
/*
 * Banh, Alex
 * CECS 277
 * Professor Phuong Nguyen
 * 14 October, 2019
 */
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
/**
 * Allows the user to make a lottery ticket and auto generates
 * winning numbers to check if the user has won any prizes
 * @author alexb
 *
 */
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Set <Integer> yourNumbers = new TreeSet<Integer>();
			Set <Integer> winningNumbers = new TreeSet<Integer>();
			Scanner scan = new Scanner(System.in);
			Random rand = new Random();
			
			yourNumbers = getTicket();
			winningNumbers = generateWinningNumbers( );
			
			System.out.println("Your ticket was: " + yourNumbers);
			System.out.println("Winning numbers: " + winningNumbers);
			
			yourNumbers.retainAll(winningNumbers);
			
			System.out.println("Match numbers: " + yourNumbers);
			
			switch (yourNumbers.size()) {
				case 0: System.out.println("Your prize is $0.00");
					break;
				case 1: System.out.println("Your prize is $5.00");
					break;
				case 2: System.out.println("Your prize is $10.00");
					break;
				case 3: System.out.println("Your prize is $20.00");
					break;
				case 4: System.out.println("Your prize is $40.00");
					break;
				case 5: System.out.println("Your prize is $80.00");
					break;
				case 6: System.out.println("Your prize is $160.00");
					break;
			}
		
		}
	/**
	 * Makes a ticket from what you input
	 * @return Returns your new ticket
	 */
	private static Set<Integer> getTicket() {
		Set <Integer> yourNumbers = new TreeSet<Integer>();
		Scanner scan = new Scanner(System.in);
		System.out.println("Type 6 lotto numbers: ");
		for (int i = 0; i < 6; i++) {
			int a = scan.nextInt();
			yourNumbers.add(a);
		}
		return yourNumbers;
	}
	/**
	 * Auto generates winning numbers for the ticket
	 * @return A set containing the winning numbers
	 */
	private static Set<Integer> generateWinningNumbers() {
		Set <Integer> winningNumbers = new TreeSet<Integer>();
		int setSize = 0;
		Random rand = new Random();
		for(int i = 0; i < 6; i++) {
			setSize = winningNumbers.size();
			winningNumbers.add(rand.nextInt(10) + 1);
			if (setSize == winningNumbers.size())
				i--;
		}
		return winningNumbers;
	}


}
