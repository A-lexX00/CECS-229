package lab7b;

public class ExtraCheese extends PizzaDecorator{
	public ExtraCheese(Pizza newPizza) {
		super(newPizza);
	}
	
	public String bakePizza() {
		return super.bakePizza() + " add Extra Cheese";
	}
}
