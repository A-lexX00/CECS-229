package lab7b;

public interface Pizza {
	public String bakePizza();
}
