package lab7b;

import java.util.Scanner;

public class Main {

	private static int choice;
	
	public static void main(String[] args) {
		String allToppings = "Pizza with";
		// TODO Auto-generated method stub
		do{
			 System.out.print("========= Pizza Menu ============ \n");
			 System.out.print(" 1. Pepperoni Pizza. \n");
			 System.out.print(" 2. Sausage Pizza.\n");
			 System.out.print(" 3. Extra Cheese Pizza. \n");
			 System.out.print(" Hit any other number to leave\n");
			 System.out.print("Enter your choice: ");
			 
			 Scanner scan = new Scanner(System.in);
			 choice = scan.nextInt();
			 
			 switch (choice) {
			 case 1:{
				 Pizza pizza = new Pepperoni(new BasePizza());
				 allToppings += " Pepperoni";
				 System.out.println("\nOrdered " + pizza.bakePizza() + '\n');
			 }
			 break;

			 case 2:{
				 Pizza pizza = new Sausage(new BasePizza());
				 allToppings += " Sausage";
				 System.out.println("\nOrdered " + pizza.bakePizza() + '\n');
			 }
			 break;
			 
			 case 3:{
				 allToppings += " Extra Cheese";
				 Pizza pizza = new ExtraCheese(new BasePizza());
				 System.out.println("\nOrdered " + pizza.bakePizza() + '\n');
			 } 
			
			 break;

			 default:{
				 System.out.println("\nBought a " + allToppings);
				 System.out.println("\nGood Bye, see you again!");
			 }
			 return;
			 	}//end of switch

			}
		while(choice < 4);
		
	} 
}


