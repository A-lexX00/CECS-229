package lab7b;

public class BasePizza implements Pizza{
	public String bakePizza() {
		return "Pizza";
	}
}
