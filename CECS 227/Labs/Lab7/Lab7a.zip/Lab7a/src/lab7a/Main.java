package lab7a;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Adaptor Test");
		SimpleName name = new SimpleName();
		name.setName("Kyle Nguyen");
		System.out.println("Simple Name: " + name.getName());
		testAdaptor(name);		
	}
	
	public static void testAdaptor(SimpleName name) {
		NameReporter adaptTest = new NameReporter(name);
		System.out.println("First Name: " + adaptTest.getFirstName());
		System.out.println("Last Name: " + adaptTest.getLastName());
	}

}
