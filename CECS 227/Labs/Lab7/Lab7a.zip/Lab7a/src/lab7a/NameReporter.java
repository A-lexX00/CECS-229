package lab7a;

public class NameReporter extends SimpleName implements FullNameInterface{

	String name;
	String fName;
	String lName;
	
	NameReporter(SimpleName name){
		this.name = name.getName();
		this.fName = name.getName().split(" ")[0];
		this.lName = name.getName().split(" ")[1];
	}
	
	@Override
	public void setFirstName(String f) {
		// TODO Auto-generated method stub
		this.fName = f;
	}

	@Override
	public void setLastName(String l) {
		// TODO Auto-generated method stub
		this.lName = l;
	}

	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return fName;
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return lName;
	}

}
