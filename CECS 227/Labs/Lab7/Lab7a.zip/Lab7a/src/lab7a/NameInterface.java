package lab7a;

public interface NameInterface {
	public void setName(String n);
	
	public String getName();
}
