package lab7c;

public class Main {
	public static void main(String[] args) {
		System.out.println("Create Boring Robot\n");
		Robot r1 = new Robot();
		System.out.println("Boring Robot Action:");
		r1.doAction();
		r1.changeState(new HappyState());
		System.out.println("Happy Robot Action:");
		r1.doAction();
	}

}
