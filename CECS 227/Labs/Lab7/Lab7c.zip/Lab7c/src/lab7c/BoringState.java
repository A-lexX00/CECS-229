package lab7c;

public class BoringState implements State{
	public BoringState() {
		
	}
	
	public void doAction() {
		System.out.println("Robot Sing");
	}
}
