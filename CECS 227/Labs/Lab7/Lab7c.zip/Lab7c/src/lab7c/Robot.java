package lab7c;

public class Robot {
	private State state;
	
	public Robot() {
		this.state = new BoringState();
	}
	
	public void changeState(State state) {
		this.state = state;
	}
	
	public void doAction() {
		this.state.doAction();
	}
}
