package lab6;

import java.io.Serializable;
/**
 * Creates Employee's to store full name and ID
 * 
 * Alex Banh 
 * 
 * @author alexb
 *
 */

public class Employee implements Serializable{
	
	private String firstName;
	private String lastName;
	private int id;
	/**
	 * Default Employee Constructor
	 */
	public Employee() {
		firstName = "";
		lastName = "";
		id = 0;
	}
	/**
	 * Normal Employee Constructor
	 * @param nFName Employee First Name
	 * @param nLName Employee Last Name
	 * @param nEmpNum Employee ID Number
	 */
	public Employee(String nFName, String nLName, int nEmpNum) {
		firstName = nFName;
		lastName = nLName;
		id = nEmpNum;
	}
	/**
	 * Prints out the Employee as a string
	 */
	public String toString() {
		return "\nID:" + id + " Name: " + lastName + ", " + firstName + "\nRating:";
	}
	public boolean equals(Employee otherEmp) {
		return (firstName == otherEmp.firstName && 
				lastName == otherEmp.lastName &&
				id == otherEmp.id);
	}
	/**
	 * return the employees as sorted
	 * @param emp compared employee
	 * @return 0 if sorted any number else as not
	 */
	public int compareTo(Employee emp)
	{
		if(this.lastName.compareTo(emp.lastName) == 0)
		{
			if(this.firstName.compareTo(emp.firstName) == 0)
			{
				return this.id - emp.id;
			}
			return this.firstName.compareTo(emp.firstName);
		}
		return this.lastName.compareTo(emp.lastName);
	}
	/**
	 * Returns the hashCode of the Employee
	 */
	public int hashCode() {
		final int HASH_MULTIPLIER = 29;
		int h = HASH_MULTIPLIER * firstName.hashCode() + lastName.hashCode();
		h = HASH_MULTIPLIER * h + ((Integer)id).hashCode();
		return h;
	}

}
