package lab6;

import java.io.*;
import java.util.*;
/**
 * Print out employee menu and store to file
 * @author alexb
 *
 */
public class EmployeeMenu implements Serializable{
	public Map<Integer, Employee> empMap;
	public Map<Employee, Integer> gradeMap;
	private static File file;
	/**
	 * Default EmployeeEmnu constructor
	 */
	public EmployeeMenu() {
		// *Redo with TreeMap
		empMap= new HashMap<Integer, Employee>() ;
		gradeMap = new HashMap<Employee, Integer>();
	}
	/**
	 * Saves to file
	 * @param em Employee Map
	 * @param gm Grade Map
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	void save(Map<Integer, Employee> em, Map<Employee, Integer> gm) throws FileNotFoundException, IOException {
        ObjectOutputStream oos1 = new ObjectOutputStream(new FileOutputStream("Employee.dat"));
        oos1.writeObject(em);
        oos1.close();
        
        ObjectOutputStream oos2 = new ObjectOutputStream(new FileOutputStream("Employee.dat"));
        oos2.writeObject(gm);
        oos2.close();
	}
	/**
	 * Gets employee map from file
	 * @return returns employee map
	 * @throws FileNotFoundException file not found
	 * @throws IOException cant read it in
	 * @throws ClassNotFoundException class not found
	 */
	public Map<Integer, Employee> getEmployee() throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Employee.dat"));
		empMap = (Map<Integer, Employee>) ois.readObject();
		ois.close();
		return empMap;
	}
	/**
	 * Gets employee performace
	 * @return returns performace map
	 * @throws FileNotFoundException file not found
	 * @throws IOException cant read it in
	 * @throws ClassNotFoundException class not found
	 */
	public Map<Employee, Integer> getPerformance() throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Employee.dat"));
		gradeMap = (Map<Employee, Integer>) ois.readObject();
		ois.close();
		return gradeMap;
	}
	/**
	 * Runs the map save
	 * @param empMen Employee Menu
	 * @throws FileNotFoundException file not found
	 * @throws ClassNotFoundException class not found
	 * @throws IOException cant read it in
	 */
	public void run(EmployeeMenu empMen) throws FileNotFoundException, ClassNotFoundException, IOException {
		file = new File("Employee.dat");
		
		if (file.length() == 0)
		{
			System.out.println("File is empty, generated empty map");
			empMen = new EmployeeMenu();
		}
		else
		{
			System.out.println("Filling map with data from file.");
			empMen.empMap = getEmployee();
			empMen.gradeMap = getPerformance();
		}
		Scanner scan = new Scanner(System.in);
		
		boolean quit = false;
		while(!quit) {
			System.out.println("Employee List: \nHit 1 to add an employee.  \nHit 2 to update an employee\n"
					+ "Hit 3 to remove an employee.  \nHit 4 to display all employees.\n"
					+ "Hit 5 to quit.");
			int get = scan.nextInt();
			switch (get) {
			case 1:
				empMen.add(empMap, gradeMap);
				break;
			case 2:
				empMen.update(empMap, gradeMap);
				break;
			case 3:
				empMen.remove(empMap, gradeMap);
				break;
			case 4:
				empMen.display(gradeMap);
				break;
			case 5:
				try {
					save(empMen.empMap, empMen.gradeMap);
					scan.close();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				quit  =  true;
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}// End Switch
		}// End While loop
		
	}
	/**
	 * Add employee to employee map and grade map
	 * @param em Employee map
	 * @param gm Grade map
	 */
	public void add(Map<Integer, Employee> em, Map<Employee, Integer> gm) {
		Scanner scan = new Scanner(System.in);

		System.out.println("Please enter ID");
		int empID = scan.nextInt();
		
				System.out.println("Please enter last name");
				String lName = scan.next();
				System.out.println("Please enter first name");
				String fName = scan.next();
				System.out.println("Please enter performance");
				int performance = scan.nextInt();
		
				Employee hold = new Employee(fName, lName, empID);
		
				em.put(empID, hold);
				gm.put(hold, performance);
	}
	/**
	 * Updates employee in grade and employee map
	 * @param em employee map
	 * @param gm grade map
	 */
	public void update(Map<Integer, Employee> em, Map<Employee, Integer> gm) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the ID of the employee you wish to modify");
		int empId = scan.nextInt();
		if (!em.containsKey(empId))
			System.out.println("No such employee exist");
		else {
			System.out.println("Please enter new performance");
			int performance = scan.nextInt();
			Employee hold = em.get(performance);
			gm.replace(hold, performance);
		}
	}
	/**
	 * removes an employee from the grade and employee map
	 * @param em employee map
	 * @param gm grade map
	 */
	public void remove(Map<Integer, Employee> em, Map<Employee, Integer> gm) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Please enter the ID you wish to remove");
		int empID = scan.nextInt();
		Employee remover = em.get(empID);
		if(gm.containsKey(remover)) {
			System.out.println("Found ID to removed");
			gm.remove(remover);
			em.remove(empID);
		}
		else {
			System.out.println("Person not found");
		}
	}
	/**
	 * Sort and display grades
	 * @param gm grade map
	 */
	public void display(Map<Employee, Integer> gm) {
		Set<Employee> empList = gm.keySet();
		ArrayList<Employee> arrListEmp = new ArrayList<Employee>();
		Iterator<Employee> iterArr = gm.keySet().iterator();
		while(iterArr.hasNext())
		{
			Employee e = iterArr.next();
			arrListEmp.add(e);
		}
		Collections.sort(arrListEmp, (o1, o2) -> o1.compareTo(o2));
		for(Employee e: arrListEmp)
			System.out.println(e.toString() + " " + gm.get(e));
	}
}
