package lab6;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;

public class Main implements Serializable{

	public static void main(String[] args) throws ClassNotFoundException, FileNotFoundException, IOException {
		EmployeeMenu empMen = new EmployeeMenu();
		empMen.run(empMen);
	}
}