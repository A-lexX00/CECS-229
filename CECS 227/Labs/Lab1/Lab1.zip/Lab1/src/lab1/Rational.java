/* Banh, Alex
 * Professor Phuong Nguyen
 * 
 * Lab 1
 *
 *CECS 277
 * 4 September 2019
 */
package lab1;

import java.util.Scanner;
/** The class Rational creates a fraction with the variables numerator and denominator
 *  and performs basic arithmetic functions on the fractions
 * 
 * @author alexb
 */
public class Rational {
	private int numerator, denominator;
	
	private int gcd(int m, int n) {
		int r;
		while(n != 0)
		{
			r = m % n;
			m = n;
			n = r;
		}
		return m;
	}
	// constructors
	/**
	 * This is the default constructor of the fraction 
	 */
	public Rational()
	{
		numerator = denominator = 0;
	}
	/**
	 * This is a normal constructor of the fraction
	 * @param nNumerator The numerator inputed
	 * @param nDenominator The denominator inputed
	 */
	public Rational(int nNumerator, int nDenominator)
	{
		numerator = nNumerator;
		denominator = nDenominator;
	}
	// getters
	/**
	 * This returns the numerator of the fraction
	 * @return Returns the numerator as an integer
	 */
	public int getNumerator() {
		return numerator;
	}
	/**
	 * This returns the denominator of the fraction
	 * @return Returns the denominator of the fraction
	 */
	public int getDenominator() {
		return denominator;
	}
	// setters
	/**
	 * This sets the numerator of a fraction as a new integer
	 * @param numerator The new numerator of the fraction
	 */
	public void setNumerator(int numerator) {
		this.numerator = numerator;
	}
	/**
	 * This sets the denominator of the fraction as a new integer
	 * @param denominator The new denominator of the fraction
	 */
	public void setDenominator(int denominator) {
		this.denominator = denominator;
	}
	// inputRational
	/**
	 * This allows us to create a new fraction by user input of the numerator or denominator
	 */
	public void inputRational() {
		System.out.println("Enter the numerator:");
		Scanner userInput = new Scanner(System.in);
		numerator = userInput.nextInt();
		System.out.println("Enter the denominator:");
		denominator = userInput.nextInt();
		System.out.println("Your fraction is: " + numerator + "/" + denominator);
	}
	// toString
	/**
	 * This prints out the fraction in one line
	 */
	public String toString() {
		if (denominator < 0)
		{
			numerator *= -1;
			denominator *= -1;
		}
		return numerator + "/" + denominator;
	}
	// functions
	/**
	 * This adds two fractions and stores it into another fraction
	 * @param r1 The first fraction we add
	 * @param r2 The second fraction we add
	 */
	public void add(Rational r1, Rational r2) {
		numerator = ((r1.numerator * r2.denominator) + (r2.numerator * r1.denominator));
		denominator = (r1.denominator * r2.denominator);
		int gcd = gcd(numerator, denominator);
		numerator /= gcd;
		denominator /= gcd;
	}
	/**
	 * This subtracts a fraction from another fraction
	 * @param r The fraction we use to subtract
	 * @return We return the new fraction
	 */
	public Rational subtract(Rational r) {
		int num = (getNumerator() * r.getDenominator()) - (r.getNumerator() * getDenominator());
		int dom = getDenominator() * r.getDenominator();
		int gcd = gcd(num, dom);
		Rational sub = new Rational(num/gcd, dom/gcd);
		return sub;
	}
	/**
	 * This multiples two fractions together and stores it into another fraction
	 * @param r1 The first fraction we multiply
	 * @param r2 The second fraction we multiply
	 */
	public void multiply(Rational r1, Rational r2) {
		numerator = (r1.numerator * r2.numerator);
		denominator = (r1.denominator * r2.denominator);
		int gcd = gcd(numerator, denominator);
		numerator /= gcd;
		denominator /= gcd;
	}
	/**
	 * This divides a fraction from another fraction
	 * @param r The fraction we use to divide
	 * @return We return the new fraction
	 */
	public Rational divide(Rational r) {
		int num = numerator * r.denominator;
		int dom = denominator * r.numerator;
		int gcd = gcd(num, dom);
		Rational div = new Rational(num /= gcd, dom /= gcd);
		return div;
	}
	/**
	 * This divides two fractions and returns the output as a decimal number
	 * @param r1 The first fraction we divide by
	 * @param r2 The second fraction we divide by
	 * @return The divisor of the two fractions as a decimal (double)
	 */
	public static double divToDouble(Rational r1, Rational r2) {
		double top, bot;
		top = r1.getNumerator() * r2.getDenominator();
		bot = r1.getDenominator() * r2.getNumerator();
		return (top / bot);
	}
}