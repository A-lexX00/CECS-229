/* Banh, Alex
 * Professor Phuong Nguyen
 * 
 * Lab 1
 *
 *CECS 277
 * 4 September 2019
 */
package lab1;


public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rational r1 = new Rational(), r2 = new Rational(), r3 = new Rational();
		r1.inputRational();
		r2.inputRational();
		r3.add(r1, r2);
		System.out.println("Add Fuction\n" + r1 + " + " + r2 + " = " + r3);
		System.out.print("Subtract Fuction\n" + r1 + " - " + r2 + " = ");
		r3 = r1.subtract(r2);
		System.out.println(r3);
		r3.multiply(r1, r2);
		System.out.println("Multiply Fuction\n" + r1 + " * " + r2 + " = " + r3);
		System.out.print("Divide Fuction\n" + r1 + " / " + r2 + " = ");
		r3 = r1.divide(r2);
		System.out.println(r3);
		System.out.println("r1: " + r1 + " r2: " + r2);
		double x = Rational.divToDouble(r1, r2);
		System.out.println("Divide into real number: " + x);
		System.out.println("Changing numberator and denominator:");
		r1.setNumerator(2);
		r2.setDenominator(5);
		System.out.println("Numerator: " + r1.getNumerator());
		System.out.println("Denominator: " + r2.getDenominator());
	}
	
}
